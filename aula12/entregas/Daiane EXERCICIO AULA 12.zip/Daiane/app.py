import random
from typing import List

class Aluno:
    def __init__(self, id: int, nome: str, pontos: int = 0, perguntas: int = 0) -> None:
        self.id = id
        self.nome = nome
        self.pontos = pontos
        self.perguntas = perguntas

    def registrar_resposta(self, pontos: int) -> None:
        """
        Registra a resposta do aluno. O valor dos pontos pode ser:
        1 para resposta parcial, 2 para resposta total, e 0 para resposta incorreta.
        """
        self.pontos += pontos

    def __str__(self) -> str:
        """
        Retorna uma representação do aluno com seu nome e pontos.
        """
        return f"{self.nome}: {self.pontos} pontos"


class Turma:
    def __init__(self, alunos: List[Aluno]) -> None:
        self.alunos = alunos
        self.index_atual = -1  # Índice para controlar o próximo aluno a ser chamado

    def proximo(self) -> Aluno:
        """
        Retorna o próximo aluno da lista, de forma que nenhum aluno seja chamado duas vezes consecutivas.
        Quando todos os alunos tiverem sido chamados, o ciclo se reinicia.
        """
        if self.index_atual == -1 or self.index_atual >= len(self.alunos) - 1:
            self.index_atual = 0  # Reinicia o ciclo de alunos
        
        # Atualiza o índice para o próximo aluno
        self.index_atual += 1
        return self.alunos[self.index_atual]

    def listar(self) -> str:
        """
        Retorna uma lista de todos os alunos com seus pontos.
        """
        return "\n".join(str(aluno) for aluno in self.alunos)


# Criando uma turma com alunos fictícios
t = Turma([
    Aluno(id=0, nome="Alisson do Nascimento Junior"),
    Aluno(id=1 , nome="Daiane da Silva Lourenço"),
    Aluno(id=2 , nome="David Gomes de Freitas"),
    Aluno(id=3 , nome="Emerson Domingues Prado"),
    Aluno(id=4 , nome="Eric Barbosa Costa"),
    Aluno(id=5 , nome="Evandro Antonio Gerola"),
    Aluno(id=6 , nome="Felipe Souza de Araujo"),
    Aluno(id=7 , nome="Guilherme Carniel"),
    Aluno(id=8 , nome="Iann Silva Ferreira"),
    Aluno(id=9 , nome="João Antonio Ribeiro do Nascimento"),
    Aluno(id=10, nome="João Luis Santana Cavalcante"),
    Aluno(id=11, nome="João Vitor Piemonte dos Santos"),
    Aluno(id=12, nome="Pamella Ribeiro de Barros"),
    Aluno(id=13, nome="Ramon da Silva Servio"),
    Aluno(id=14, nome="Regiane Maria Rosa Castro"),
    Aluno(id=15, nome="Robson Calheira dos Santos"),
    Aluno(id=16, nome="Rodrigo Faria de Souza"),
    Aluno(id=17, nome="Valkíria de Sena Santos"),
    Aluno(id=18, nome="Valter André da Costa"),
    Aluno(id=19, nome="Victor Henrique Rossi Mazete"),
    Aluno(id=20, nome="Wilton Ferreira do Nascimento")
])

# Método para o loop interativo onde pergunta, registra e exibe respostas
while True:
    # Obtém o próximo aluno a ser perguntado
    pa = t.proximo()
    print(f"Pergunta a {pa.nome}")

    # Pergunta se a resposta foi correta e registra os pontos
    pontos = input("Resposta correta? 1 Parcial, 2 Total, 0 Incorreta: ")
    try:
        pontos = int(pontos)
        pa.registrar_resposta(pontos)
    except ValueError:
        print("Por favor, insira um número válido.")
        continue

    # Pergunta se deseja perguntar novamente
    resp = input(f"Perguntar novamente? S/N: ").strip().upper()

    if resp == "N":
        print("Resultados finais:")
        print(t.listar())  # Exibe a lista de alunos e seus pontos
        break  # Encerra o loo